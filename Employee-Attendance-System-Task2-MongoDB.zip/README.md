# Employee Attendance System (Task-2) - MongoDB Version

This is a minimal full-stack implementation for the Task-2 Employee Attendance System.
It includes:
- Backend: Node.js + Express + MongoDB (Mongoose)
- Frontend: React (Vite-compatible structure, minimal dependencies)
- JWT authentication, basic attendance endpoints, seed data.

## Quick start (local)

### Prerequisites
- Node.js (v16+)
- npm
- MongoDB running locally (or use MongoDB Atlas)

### Backend
```bash
cd server
npm install
# copy .env.example to .env and update MONGO_URI and JWT_SECRET
node src/seed.js    # creates seed users & sample attendance
npm run dev        # starts server on PORT (default 5000)
```

### Frontend
```bash
cd client
npm install
# copy .env.example to .env and update VITE_API_URL (e.g. http://localhost:5000)
npm run dev        # starts dev server (default 5173)
```

## Deliverables included
- `server/` - backend code, models, routes, seed script
- `client/` - React frontend (basic UI)
- `.env.example` files
- `README.md` with instructions

This project is minimal but fully functional to meet Task-2 requirements. Customize UI and extend features as needed.
