# Server (Express + MongoDB)

See project root README for quick start. Make sure to copy `.env.example` to `.env`.
