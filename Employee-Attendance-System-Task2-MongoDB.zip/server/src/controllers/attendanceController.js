const Attendance = require('../models/Attendance');
const User = require('../models/User');
const csvWriter = require('csv-writer').createObjectCsvStringifier;

function todayStr() {
  const d = new Date();
  return d.toISOString().slice(0,10);
}

exports.checkIn = async (req, res) => {
  const user = req.user;
  const date = todayStr();
  try {
    let att = await Attendance.findOne({ userId:user._id, date });
    if (att) return res.status(400).json({ message:'Already checked in' });
    att = await Attendance.create({ userId:user._id, date, checkInTime: new Date().toISOString(), status:'present' });
    res.json(att);
  } catch (err) { console.error(err); res.status(500).json({ message:'Server error' }); }
};

exports.checkOut = async (req, res) => {
  const user = req.user;
  const date = todayStr();
  try {
    let att = await Attendance.findOne({ userId:user._id, date });
    if (!att) return res.status(400).json({ message:'Not checked in' });
    if (att.checkOutTime) return res.status(400).json({ message:'Already checked out' });
    att.checkOutTime = new Date().toISOString();
    // compute hours
    const hours = (new Date(att.checkOutTime) - new Date(att.checkInTime)) / (1000*60*60);
    att.totalHours = Math.round(hours * 100)/100;
    await att.save();
    res.json(att);
  } catch (err) { console.error(err); res.status(500).json({ message:'Server error' }); }
};

exports.myHistory = async (req, res) => {
  try {
    const list = await Attendance.find({ userId:req.user._id }).sort({ date:-1 }).limit(365);
    res.json(list);
  } catch (err) { console.error(err); res.status(500).json({ message:'Server error' }); }
};

exports.mySummary = async (req, res) => {
  try {
    const month = (new Date()).getMonth();
    const year = (new Date()).getFullYear();
    const list = await Attendance.find({ userId:req.user._id });
    // simple summary
    const present = list.filter(l=>l.status==='present').length;
    res.json({ present, total: list.length });
  } catch (err) { console.error(err); res.status(500).json({ message:'Server error' }); }
};

exports.todayStatus = async (req, res) => {
  try {
    const date = todayStr();
    const att = await Attendance.findOne({ userId:req.user._id, date });
    res.json({ date, status: att ? 'checked' : 'not-checked', attendance:att });
  } catch (err) { console.error(err); res.status(500).json({ message:'Server error' }); }
};

// Manager endpoints (simple role check)
function isManager(req) {
  return req.user && req.user.role === 'manager';
}

exports.allAttendance = async (req, res) => {
  if (!isManager(req)) return res.status(403).json({ message:'Forbidden' });
  const list = await Attendance.find().populate('userId','name employeeId department');
  res.json(list);
};

exports.byEmployee = async (req, res) => {
  if (!isManager(req)) return res.status(403).json({ message:'Forbidden' });
  const list = await Attendance.find({ userId: req.params.id }).sort({ date:-1 });
  res.json(list);
};

exports.teamSummary = async (req, res) => {
  if (!isManager(req)) return res.status(403).json({ message:'Forbidden' });
  const totalEmployees = await User.countDocuments({ role:'employee' });
  const todays = await Attendance.find({ date: todayStr() }).countDocuments();
  res.json({ totalEmployees, todays });
};

exports.exportCSV = async (req, res) => {
  if (!isManager(req)) return res.status(403).json({ message:'Forbidden' });
  const list = await Attendance.find().populate('userId','name employeeId department');
  const csv = csvWriter({
    header: [
      {id:'user', title:'User'},
      {id:'emp', title:'EmployeeId'},
      {id:'date', title:'Date'},
      {id:'checkIn', title:'CheckIn'},
      {id:'checkOut', title:'CheckOut'},
      {id:'status', title:'Status'},
      {id:'hours', title:'TotalHours'}
    ]
  }).stringifyRecords(list.map(it=>({
    user: it.userId?.name || '',
    emp: it.userId?.employeeId || '',
    date: it.date,
    checkIn: it.checkInTime || '',
    checkOut: it.checkOutTime || '',
    status: it.status,
    hours: it.totalHours || 0
  })));
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename=attendance.csv');
  res.send(csv);
};
