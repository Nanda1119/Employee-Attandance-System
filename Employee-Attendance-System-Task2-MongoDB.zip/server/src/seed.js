/*
Seed script: creates manager + employees and some attendance entries.
Run with: node src/seed.js
*/
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Attendance = require('./models/Attendance');

async function seed(){
  await mongoose.connect(process.env.MONGO_URI);
  await User.deleteMany({});
  await Attendance.deleteMany({});
  const salt = await bcrypt.genSalt(10);
  const manager = await User.create({
    name:'Alice Manager', email:'manager@example.com',
    password: await bcrypt.hash('password', salt),
    role:'manager', employeeId: 'MGR001', department: 'Management'
  });
  const emp1 = await User.create({
    name:'Bob Employee', email:'bob@example.com',
    password: await bcrypt.hash('password', salt),
    role:'employee', employeeId: 'EMP001', department: 'Sales'
  });
  const emp2 = await User.create({
    name:'Carol Employee', email:'carol@example.com',
    password: await bcrypt.hash('password', salt),
    role:'employee', employeeId: 'EMP002', department: 'Engineering'
  });
  // create few attendance days
  const dates = ['2025-11-25','2025-11-26','2025-11-27'];
  for(const d of dates){
    await Attendance.create({ userId: emp1._id, date: d, checkInTime: new Date().toISOString(), checkOutTime: new Date().toISOString(), status:'present', totalHours:8 });
    await Attendance.create({ userId: emp2._id, date: d, checkInTime: new Date().toISOString(), checkOutTime: new Date().toISOString(), status:'present', totalHours:8 });
  }
  console.log('Seed complete. Manager login: manager@example.com / password');
  process.exit(0);
}

seed().catch(err=>{ console.error(err); process.exit(1); });
