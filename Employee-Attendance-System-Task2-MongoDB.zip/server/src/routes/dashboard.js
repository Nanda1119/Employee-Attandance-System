const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Attendance = require('../models/Attendance');
const User = require('../models/User');

router.get('/employee', auth, async (req,res)=>{
  // simple employee stats
  const userId = req.user._id;
  const month = new Date().getMonth();
  const list = await Attendance.find({ userId });
  res.json({ total: list.length, recent: list.slice(0,7) });
});

router.get('/manager', auth, async (req,res)=>{
  if (req.user.role !== 'manager') return res.status(403).json({ message:'Forbidden' });
  const totalEmployees = await User.countDocuments({ role:'employee' });
  const todays = await Attendance.find({ date: new Date().toISOString().slice(0,10) }).countDocuments();
  res.json({ totalEmployees, todays });
});

module.exports = router;
