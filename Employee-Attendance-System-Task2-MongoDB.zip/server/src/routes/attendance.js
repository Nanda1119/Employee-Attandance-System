const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const ctrl = require('../controllers/attendanceController');

router.post('/checkin', auth, ctrl.checkIn);
router.post('/checkout', auth, ctrl.checkOut);
router.get('/my-history', auth, ctrl.myHistory);
router.get('/my-summary', auth, ctrl.mySummary);
router.get('/today', auth, ctrl.todayStatus);

// Manager routes
router.get('/all', auth, ctrl.allAttendance);
router.get('/employee/:id', auth, ctrl.byEmployee);
router.get('/summary', auth, ctrl.teamSummary);
router.get('/export', auth, ctrl.exportCSV);

module.exports = router;
