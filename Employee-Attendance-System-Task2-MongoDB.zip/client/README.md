# Client (React + Vite)

- Copy .env.example to .env and set VITE_API_URL to backend (e.g. http://localhost:5000)
- `npm install`
- `npm run dev`
