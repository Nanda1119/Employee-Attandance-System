import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import EmployeeDashboard from './pages/EmployeeDashboard';
import ManagerDashboard from './pages/ManagerDashboard';
import MarkAttendance from './pages/MarkAttendance';
import AttendanceHistory from './pages/AttendanceHistory';

export default function App(){
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <nav>
        <Link to='/login'>Login</Link> | <Link to='/register'>Register</Link> | <Link to='/employee'>Employee</Link> | <Link to='/manager'>Manager</Link>
      </nav>
      <hr/>
      <Routes>
        <Route path='/' element={<Login/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/register' element={<Register/>}/>
        <Route path='/employee' element={<EmployeeDashboard/>}/>
        <Route path='/manager' element={<ManagerDashboard/>}/>
        <Route path='/mark' element={<MarkAttendance/>}/>
        <Route path='/history' element={<AttendanceHistory/>}/>
      </Routes>
    </div>
  );
}
