import React, {useEffect, useState} from 'react';
import API, { setAuthToken } from '../api';
export default function ManagerDashboard(){
  const [data,setData]=useState('');
  useEffect(()=>{ const t=localStorage.getItem('token'); if(t) setAuthToken(t); },[]);
  const load = async ()=> {
    try{ const res = await API.get('/api/dashboard/manager'); setData(JSON.stringify(res.data)); }
    catch(err){ setData(err?.response?.data?.message || 'Error'); }
  };
  return (
    <div>
      <h2>Manager Dashboard</h2>
      <button onClick={load}>Load Team Stats</button>
      <div><a href='/'>Home</a></div>
      <pre>{data}</pre>
    </div>
  );
}
