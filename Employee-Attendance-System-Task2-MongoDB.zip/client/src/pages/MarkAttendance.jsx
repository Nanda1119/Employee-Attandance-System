import React from 'react';
import API, { setAuthToken } from '../api';
export default function MarkAttendance(){
  const t = localStorage.getItem('token'); if(t) setAuthToken(t);
  const checkIn = async ()=> {
    try{ await API.post('/api/attendance/checkin'); alert('Checked in'); }catch(e){ alert(e?.response?.data?.message || 'Error'); }
  };
  const checkOut = async ()=> {
    try{ await API.post('/api/attendance/checkout'); alert('Checked out'); }catch(e){ alert(e?.response?.data?.message || 'Error'); }
  };
  return (
    <div>
      <h2>Mark Attendance</h2>
      <button onClick={checkIn}>Check In</button> <button onClick={checkOut}>Check Out</button>
    </div>
  );
}
