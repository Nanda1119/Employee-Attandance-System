import React, {useEffect, useState} from 'react';
import API, { setAuthToken } from '../api';
export default function EmployeeDashboard(){
  const [status,setStatus]=useState('');
  useEffect(()=>{ const t = localStorage.getItem('token'); if(t) setAuthToken(t); },[]);
  const check = async ()=> {
    try{ const res = await API.get('/api/attendance/today'); setStatus(JSON.stringify(res.data)); }
    catch(err){ setStatus('Error'); }
  };
  return (
    <div>
      <h2>Employee Dashboard</h2>
      <button onClick={check}>Get Today's Status</button>
      <div><a href='/mark'>Mark Attendance</a> | <a href='/history'>My History</a></div>
      <pre>{status}</pre>
    </div>
  );
}
