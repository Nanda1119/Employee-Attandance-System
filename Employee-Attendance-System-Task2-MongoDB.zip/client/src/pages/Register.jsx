import React, {useState} from 'react';
import API from '../api';
export default function Register(){
  const [name,setName]=useState('New User');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');
  const submit = async e => {
    e.preventDefault();
    try{ await API.post('/api/auth/register',{ name,email,password,role:'employee' }); setMsg('Registered - now login'); }
    catch(err){ setMsg(err?.response?.data?.message || 'Error'); }
  };
  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder='name'/><br/>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='email'/><br/>
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder='password' type='password'/><br/>
        <button>Register</button>
      </form>
      <p>{msg}</p>
    </div>
  );
}
