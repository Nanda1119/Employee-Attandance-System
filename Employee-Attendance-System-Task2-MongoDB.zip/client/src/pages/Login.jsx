import React, {useState} from 'react';
import API, { setAuthToken } from '../api';

export default function Login(){
  const [email,setEmail]=useState('manager@example.com');
  const [password,setPassword]=useState('password');
  const [msg,setMsg]=useState('');
  const handle = async (e) => {
    e.preventDefault();
    try{
      const res = await API.post('/api/auth/login',{ email,password });
      const { token, user } = res.data;
      localStorage.setItem('token', token);
      setAuthToken(token);
      setMsg('Logged in as ' + user.role);
    }catch(err){ setMsg(err?.response?.data?.message || 'Error'); }
  };
  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handle}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='email'/><br/>
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder='password' type='password'/><br/>
        <button>Login</button>
      </form>
      <p>{msg}</p>
    </div>
  );
}
