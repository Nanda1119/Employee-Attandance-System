import React, {useEffect, useState} from 'react';
import API, { setAuthToken } from '../api';
export default function AttendanceHistory(){
  const [list,setList]=useState([]);
  useEffect(()=>{ const t=localStorage.getItem('token'); if(t) setAuthToken(t); (async ()=>{ try{ const r=await API.get('/api/attendance/my-history'); setList(r.data); }catch(e){ console.error(e); } })(); },[]);
  return (
    <div>
      <h2>My Attendance History</h2>
      <table border='1'>
        <thead><tr><th>Date</th><th>CheckIn</th><th>CheckOut</th><th>Status</th><th>TotalHours</th></tr></thead>
        <tbody>
          {list.map(it=> <tr key={it._id}><td>{it.date}</td><td>{it.checkInTime||''}</td><td>{it.checkOutTime||''}</td><td>{it.status}</td><td>{it.totalHours}</td></tr>)}
        </tbody>
      </table>
    </div>
  );
}
